package com.form.authentication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.form.authentication.dao.UserRepo;
import com.form.authentication.model.User;
import com.form.authentication.service.UserService;

@Controller
public class HomeController {
    
    @Autowired
    UserRepo userRepo;

    // login page
    @RequestMapping({"login"})
    public String login() {
        return "login";
    }

    // signup page
    @RequestMapping({"/", "signup"})
    public String signup() {
        return "signup";
    }

    // after signup details display page
    @RequestMapping("signupdetails")
    public ModelAndView signupDetails(User user) {
        ModelAndView mv = new ModelAndView();
        if (UserService.passwordChecking(user)) {
            userRepo.save(user);
            mv.addObject("user", user);    
            mv.setViewName("signupDetails");
        }
        else mv.setViewName("error");
        return mv;
    }
    
}
