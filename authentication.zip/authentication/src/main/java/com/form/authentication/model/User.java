package com.form.authentication.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class User {
    
    @Id
    private String firstName;
    private String lastName;
    private String gmail;
    private String phoneNo;
    private String password;
    private String conformPassword;
    
    public User() {
    }

    public User(String firstName, String lastName, String gmail, String phoneNo, String password,
            String conformPassword) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gmail = gmail;
        this.phoneNo = phoneNo;
        this.password = password;
        this.conformPassword = conformPassword;
    }
    
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getGmail() {
        return gmail;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getConformPassword() {
        return conformPassword;
    }

    public void setConformPassword(String conformPassword) {
        this.conformPassword = conformPassword;
    }

    @Override
    public String toString() {
        return "User [firstName=" + firstName + ", lastName=" + lastName + ", gmail=" + gmail + ", phoneNo=" + phoneNo
                + ", password=" + password + ", conformPassword=" + conformPassword + "]";
    }
}
