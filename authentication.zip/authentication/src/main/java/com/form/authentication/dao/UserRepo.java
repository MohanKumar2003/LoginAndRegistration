package com.form.authentication.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.form.authentication.model.User;

public interface UserRepo extends JpaRepository<User,String> {
  
}
