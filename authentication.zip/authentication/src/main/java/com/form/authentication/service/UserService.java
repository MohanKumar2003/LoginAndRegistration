package com.form.authentication.service;

import com.form.authentication.model.User;

public class UserService {

    // password checking
    public static boolean passwordChecking(User user) {
        if (user.getPassword().toLowerCase().equals(user.getConformPassword().toLowerCase())) { 
            return true;
        }
        else return false;
    }
}
